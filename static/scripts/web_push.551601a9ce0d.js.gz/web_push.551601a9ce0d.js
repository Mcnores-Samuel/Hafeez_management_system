// const callModal = () => {
//   const allowWebBtn = $('#webpush-subscribe-button');
//   const modal = $('#web_push_request');

//   if (allowWebBtn.text().includes('Subscribe')) {
//     modal.modal('show');
//   } else {
//     modal.modal('hide');
//   }
// };

// $(document).ready(() => {
//   setTimeout(callModal, 20000);
// });

{
    "current_year": {
        "january": {
            "agent__username1": 10,
            "agent__username2": 12,
            "agent__username3": 15
        },
        "february": {
            "agent__username1": 20,
            "agent__username2": 22,
            "agent__username3": 25
        },
        "march": {
            "agent__username1": 30,
            "agent__username2": 32,
            "agent__username3": 35
        },
        "april": {
            "agent__username1": 40,
            "agent__username2": 42,
            "agent__username3": 45
        },

        "may": {
            "agent__username1": 50,
            "agent__username2": 52,
            "agent__username3": 55
        },
        "june": {
            "agent__username1": 60,
            "agent__username2": 62,
            "agent__username3": 65
        },
        "july": {
            "agent__username1": 70,
            "agent__username2": 72,
            "agent__username3": 75
        },
        "august": {
            "agent__username1": 80,
            "agent__username2": 82,
            "agent__username3": 85
        },
        // up to december
        }
    },
    "last_year": {
        "january": {
            "agent__username1": 5,
            "agent__username2": 7,
            "agent__username3": 10
        },
        "february": {
            "agent__username1": 15,
            "agent__username2": 17,
            "agent__username3": 20
        },
        "march": {
            "agent__username1": 25,
            "agent__username2": 27,
            "agent__username3": 30
        },
        "april": {
            "agent__username1": 35,
            "agent__username2": 37,
            "agent__username3": 40
        },
        "may": {
            "agent__username1": 45,
            "agent__username2": 47,
            "agent__username3": 50
        },
        "june": {
            "agent__username1": 55,
            "agent__username2": 57,
            "agent__username3": 60
        },
        "july": {
            "agent__username1": 65,
            "agent__username2": 67,
            "agent__username3": 70
        },
        "august": {
            "agent__username1": 75,
            "agent__username2": 77,
            "agent__username3": 80
        },
        // up to december
        }
    }
}